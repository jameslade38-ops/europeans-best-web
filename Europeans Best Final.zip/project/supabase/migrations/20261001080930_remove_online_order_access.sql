/*
# Restrict staff creation to owners

1. Security change
- Removes default PUBLIC and anonymous execution from `create_staff_member`.
- The function remains available only to signed-in users, and it still checks owner status internally.
*/

REVOKE EXECUTE ON FUNCTION public.create_staff_member(text, text, text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.create_staff_member(text, text, text) TO authenticated;