/*
# Time-off requests, remove auto clock-in/out, add activity logging to time updates

## 1. New Tables
- `time_off_requests` — staff time-off requests visible to owner and manager
  - `id` uuid primary key
  - `staff_id` uuid references staff_members(id)
  - `start_date` date — first day of requested time off
  - `end_date` date — last day of requested time off
  - `reason` text — why the time off is needed
  - `status` text — 'pending', 'approved', 'denied' (default 'pending')
  - `created_at` timestamptz default now()

## 2. Modified Functions
- `staff_sign_in` — remove the auto clock-in that fires when a staff member signs in.
  Staff must explicitly press Clock In. The function now only returns the dashboard.
- `auto_clock_out_staff` — kept but no longer called from staff_sign_in or staff_clock_action.
  Only the owner's panel may trigger it (owner_auto_clock_out_staff).
- `owner_update_clock_event` — now inserts an activity_log entry after updating.
- `staff_manager_update_clock_event` — now inserts an activity_log entry after updating.
- New function `staff_request_time_off(p_pin, p_start_date, p_end_date, p_reason)` — lets a
  staff member submit a time-off request from the staff kiosk.
- New function `staff_manager_update_time_off(p_pin, p_request_id, p_status)` — lets a
  manager or owner approve/deny a time-off request.

## 3. Security
- Enable RLS on `time_off_requests`.
- Owner can read, update, delete all time-off requests (via is_owner()).
- Staff can insert their own time-off requests (via staff_request_time_off function).
- Owner and manager can approve/deny (via staff_manager_update_time_off function).
- Public SELECT on time_off_requests is denied — only owner can read through RLS.
  The staff kiosk reads time-off through the SECURITY DEFINER dashboard function.
- All functions are SECURITY DEFINER with locked search_path.
*/

CREATE TABLE IF NOT EXISTS public.time_off_requests (
  id uuid PRIMARY KEY DEFAULT extensions.gen_random_uuid(),
  staff_id uuid NOT NULL REFERENCES public.staff_members(id) ON DELETE CASCADE,
  start_date date NOT NULL,
  end_date date NOT NULL,
  reason text NOT NULL DEFAULT '',
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','denied')),
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.time_off_requests ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Owners can read time off requests" ON public.time_off_requests;
CREATE POLICY "Owners can read time off requests" ON public.time_off_requests
  FOR SELECT TO authenticated USING (public.is_owner());

DROP POLICY IF EXISTS "Owners can delete time off requests" ON public.time_off_requests;
CREATE POLICY "Owners can delete time off requests" ON public.time_off_requests
  FOR DELETE TO authenticated USING (public.is_owner());

-- Allow owner to update status directly (for the dashboard panel)
DROP POLICY IF EXISTS "Owners can update time off requests" ON public.time_off_requests;
CREATE POLICY "Owners can update time off requests" ON public.time_off_requests
  FOR UPDATE TO authenticated USING (public.is_owner()) WITH CHECK (public.is_owner());

-- Grant basic table access
GRANT SELECT, INSERT, UPDATE, DELETE ON public.time_off_requests TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.time_off_requests TO anon;

-- ── Remove auto clock-in from staff_sign_in ──
CREATE OR REPLACE FUNCTION public.staff_sign_in(p_name text, p_pin text)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public', 'extensions'
AS $function$
DECLARE v_staff public.staff_members;
BEGIN
IF p_name IS NULL OR char_length(trim(p_name)) < 2 OR p_pin IS NULL OR p_pin !~ '^[0-9]{4,12}$' THEN RAISE EXCEPTION 'Invalid kiosk entry'; END IF;
SELECT * INTO v_staff FROM public.staff_members WHERE is_active = true AND split_part(lower(trim(display_name)), ' ', 1) = lower(trim(p_name)) AND crypt(p_pin, pin_hash) = pin_hash LIMIT 1;
IF v_staff.id IS NULL THEN RAISE EXCEPTION 'Invalid kiosk entry'; END IF;
RETURN public.staff_dashboard(p_pin);
END;
$function$;

-- ── Remove auto_clock_out_staff call from staff_clock_action ──
CREATE OR REPLACE FUNCTION public.staff_clock_action(p_pin text, p_action text, p_note text DEFAULT ''::text)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public', 'extensions'
AS $function$
DECLARE v_staff public.staff_members; v_last_event text;
BEGIN
SELECT * INTO v_staff FROM public.staff_members WHERE is_active = true AND crypt(p_pin, pin_hash) = pin_hash LIMIT 1;
IF v_staff.id IS NULL THEN RAISE EXCEPTION 'Invalid kiosk entry'; END IF;
IF p_action NOT IN ('clock_in', 'clock_out', 'break_start', 'break_end') THEN RAISE EXCEPTION 'Invalid clock action'; END IF;
SELECT event_type INTO v_last_event FROM public.clock_events WHERE staff_id = v_staff.id ORDER BY created_at DESC LIMIT 1;
IF p_action = 'clock_in' AND v_last_event IN ('clock_in', 'break_end') THEN RAISE EXCEPTION 'Already clocked in'; END IF;
IF p_action = 'clock_out' AND v_last_event NOT IN ('clock_in', 'break_end') THEN RAISE EXCEPTION 'Not clocked in'; END IF;
IF p_action = 'break_start' AND v_last_event <> 'clock_in' THEN RAISE EXCEPTION 'Not clocked in'; END IF;
IF p_action = 'break_end' AND v_last_event <> 'break_start' THEN RAISE EXCEPTION 'Not on break'; END IF;
INSERT INTO public.clock_events (staff_id, event_type, notes) VALUES (v_staff.id, p_action, left(coalesce(p_note, ''), 500));
RETURN public.staff_dashboard(p_pin);
END;
$function$;

-- ── Owner update clock event with activity logging ──
CREATE OR REPLACE FUNCTION public.owner_update_clock_event(p_event_id uuid, p_event_type text, p_created_at timestamp with time zone, p_note text DEFAULT ''::text)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public', 'extensions'
AS $function$
DECLARE v_staff_id uuid; v_staff_name text;
BEGIN
IF NOT public.is_owner() THEN RAISE EXCEPTION 'Not authorized'; END IF;
IF p_event_type NOT IN ('clock_in', 'clock_out', 'break_start', 'break_end') THEN RAISE EXCEPTION 'Invalid event'; END IF;
SELECT staff_id INTO v_staff_id FROM public.clock_events WHERE id = p_event_id;
IF v_staff_id IS NULL THEN RETURN false; END IF;
SELECT display_name INTO v_staff_name FROM public.staff_members WHERE id = v_staff_id;
UPDATE public.clock_events SET event_type = p_event_type, created_at = p_created_at, notes = left(coalesce(p_note, ''), 500) WHERE id = p_event_id;
INSERT INTO public.activity_logs (action, details, actor_user_id)
  VALUES ('Updated time entry', COALESCE(v_staff_name, 'Staff member') || ': ' || p_event_type || ' at ' || p_created_at::text, auth.uid());
RETURN true;
END;
$function$;

-- ── Manager update clock event with activity logging ──
CREATE OR REPLACE FUNCTION public.staff_manager_update_clock_event(p_pin text, p_event_id uuid, p_event_type text, p_created_at timestamp with time zone, p_note text DEFAULT ''::text)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public', 'extensions'
AS $function$
DECLARE v_staff public.staff_members; v_target_staff_id uuid; v_target_name text;
BEGIN
SELECT * INTO v_staff FROM public.staff_members WHERE is_active = true AND crypt(p_pin, pin_hash) = pin_hash LIMIT 1;
IF v_staff.id IS NULL OR v_staff.role <> 'manager' THEN RAISE EXCEPTION 'Not authorized'; END IF;
IF p_event_type NOT IN ('clock_in', 'clock_out', 'break_start', 'break_end') THEN RAISE EXCEPTION 'Invalid event'; END IF;
SELECT staff_id INTO v_target_staff_id FROM public.clock_events WHERE id = p_event_id;
IF v_target_staff_id IS NULL THEN RETURN false; END IF;
SELECT display_name INTO v_target_name FROM public.staff_members WHERE id = v_target_staff_id;
UPDATE public.clock_events SET event_type = p_event_type, created_at = p_created_at, notes = left(coalesce(p_note, ''), 500) WHERE id = p_event_id;
INSERT INTO public.activity_logs (action, details, actor_user_id)
  VALUES ('Manager updated time entry', COALESCE(v_target_name, 'Staff member') || ': ' || p_event_type || ' at ' || p_created_at::text || ' (by ' || v_staff.display_name || ')', null);
RETURN true;
END;
$function$;

-- ── Staff request time off ──
CREATE OR REPLACE FUNCTION public.staff_request_time_off(p_pin text, p_start_date date, p_end_date date, p_reason text DEFAULT ''::text)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public', 'extensions'
AS $function$
DECLARE v_staff public.staff_members;
BEGIN
SELECT * INTO v_staff FROM public.staff_members WHERE is_active = true AND crypt(p_pin, pin_hash) = pin_hash LIMIT 1;
IF v_staff.id IS NULL THEN RAISE EXCEPTION 'Invalid staff code'; END IF;
IF p_start_date IS NULL OR p_end_date IS NULL OR p_end_date < p_start_date THEN RAISE EXCEPTION 'Invalid date range'; END IF;
INSERT INTO public.time_off_requests (staff_id, start_date, end_date, reason)
  VALUES (v_staff.id, p_start_date, p_end_date, left(coalesce(p_reason, ''), 500));
RETURN true;
END;
$function$;

-- ── Manager/owner approve or deny time off ──
CREATE OR REPLACE FUNCTION public.staff_manager_update_time_off(p_pin text, p_request_id uuid, p_status text)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public', 'extensions'
AS $function$
DECLARE v_staff public.staff_members;
BEGIN
SELECT * INTO v_staff FROM public.staff_members WHERE is_active = true AND crypt(p_pin, pin_hash) = pin_hash LIMIT 1;
IF v_staff.id IS NULL OR v_staff.role <> 'manager' THEN RAISE EXCEPTION 'Not authorized'; END IF;
IF p_status NOT IN ('approved', 'denied') THEN RAISE EXCEPTION 'Invalid status'; END IF;
UPDATE public.time_off_requests SET status = p_status WHERE id = p_request_id;
RETURN true;
END;
$function$;

-- Grant execute on new functions
GRANT EXECUTE ON FUNCTION public.staff_request_time_off TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.staff_manager_update_time_off TO anon, authenticated;
