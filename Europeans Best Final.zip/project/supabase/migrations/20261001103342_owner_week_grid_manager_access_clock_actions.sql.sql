/*
# Owner week clock grid, manager access to messages/time-off/hours, clock actions from panel

## 1. New Functions
- `owner_week_clock_grid(p_week_start date)` — returns all active staff with their clock events
  for the given week (Sunday–Saturday), grouped per staff member per day. Each day entry includes
  clock_in time, clock_out time, break_start, break_end, notes, and whether currently clocked in.
  Owner-only (SECURITY DEFINER, is_owner check).
- `owner_clock_action(p_staff_id uuid, p_action text, p_note text)` — lets the owner manually
  clock a staff member in/out/start break/end break from the control panel grid.
- `staff_manager_clock_action(p_pin text, p_staff_id uuid, p_action text, p_note text)` — lets
  a manager clock a staff member in/out/start break/end break from the manager panel grid.

## 2. Modified RLS
- `contact_messages` — add SELECT policy for managers (staff_members.role = 'manager' via a
  helper check). Owners already have access via is_owner().
- `time_off_requests` — add SELECT policy for managers so they can see pending requests.
- `site_hours` — add SELECT policy for managers (already public-read via anon, but this makes
  it explicit for authenticated manager sessions).

## 3. Security
- All new functions are SECURITY DEFINER with locked search_path.
- Owner functions check is_owner().
- Manager functions verify the caller's role is 'manager' via their pin.
- No new tables or columns are created.
*/

-- Helper: check if current auth user is a manager (linked to an active staff_members row with role='manager')
CREATE OR REPLACE FUNCTION public.is_manager()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path TO 'public', 'extensions'
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.staff_members sm
    JOIN public.owner_accounts oa ON oa.user_id = auth.uid()
    WHERE sm.is_active = true AND sm.role = 'manager'
    LIMIT 1
  ) OR public.is_owner();
$$;

-- Owner: get the full week grid of all active staff and their clock events
CREATE OR REPLACE FUNCTION public.owner_week_clock_grid(p_week_start date)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public', 'extensions'
AS $function$
DECLARE
  v_week_end date := p_week_start + 6;
  v_staff RECORD;
  v_grid jsonb := '[]'::jsonb;
BEGIN
  IF NOT public.is_owner() THEN RAISE EXCEPTION 'Not authorized'; END IF;

  FOR v_staff IN
    SELECT id, display_name, role
    FROM public.staff_members
    WHERE is_active = true
    ORDER BY display_name
  LOOP
    SELECT jsonb_build_object(
      'staff_id', v_staff.id,
      'display_name', v_staff.display_name,
      'role', v_staff.role,
      'days', COALESCE((
        SELECT jsonb_agg(
          jsonb_build_object(
            'date', d.day_date,
            'day_name', to_char(d.day_date, 'Day'),
            'clock_in', (
              SELECT to_char(ce.created_at, 'HH12:MI AM')
              FROM public.clock_events ce
              WHERE ce.staff_id = v_staff.id
                AND ce.event_type = 'clock_in'
                AND ce.created_at::date = d.day_date
              ORDER BY ce.created_at DESC LIMIT 1
            ),
            'clock_in_raw', (
              SELECT to_char(ce.created_at, 'YYYY-MM-DD"T"HH24:MI')
              FROM public.clock_events ce
              WHERE ce.staff_id = v_staff.id
                AND ce.event_type = 'clock_in'
                AND ce.created_at::date = d.day_date
              ORDER BY ce.created_at DESC LIMIT 1
            ),
            'clock_out', (
              SELECT to_char(ce.created_at, 'HH12:MI AM')
              FROM public.clock_events ce
              WHERE ce.staff_id = v_staff.id
                AND ce.event_type = 'clock_out'
                AND ce.created_at::date = d.day_date
              ORDER BY ce.created_at DESC LIMIT 1
            ),
            'clock_out_raw', (
              SELECT to_char(ce.created_at, 'YYYY-MM-DD"T"HH24:MI')
              FROM public.clock_events ce
              WHERE ce.staff_id = v_staff.id
                AND ce.event_type = 'clock_out'
                AND ce.created_at::date = d.day_date
              ORDER BY ce.created_at DESC LIMIT 1
            ),
            'break_start', (
              SELECT to_char(ce.created_at, 'HH12:MI AM')
              FROM public.clock_events ce
              WHERE ce.staff_id = v_staff.id
                AND ce.event_type = 'break_start'
                AND ce.created_at::date = d.day_date
              ORDER BY ce.created_at DESC LIMIT 1
            ),
            'break_end', (
              SELECT to_char(ce.created_at, 'HH12:MI AM')
              FROM public.clock_events ce
              WHERE ce.staff_id = v_staff.id
                AND ce.event_type = 'break_end'
                AND ce.created_at::date = d.day_date
              ORDER BY ce.created_at DESC LIMIT 1
            ),
            'notes', (
              SELECT string_agg(ce.notes, ' | ')
              FROM public.clock_events ce
              WHERE ce.staff_id = v_staff.id
                AND ce.created_at::date = d.day_date
                AND ce.notes <> ''
            ),
            'is_currently_in', (
              SELECT EXISTS (
                SELECT 1 FROM public.clock_events ce
                WHERE ce.staff_id = v_staff.id
                  AND ce.created_at::date = d.day_date
                  AND ce.event_type IN ('clock_in', 'break_end')
                  AND NOT EXISTS (
                    SELECT 1 FROM public.clock_events ce2
                    WHERE ce2.staff_id = v_staff.id
                      AND ce2.created_at::date = d.day_date
                      AND ce2.created_at > ce.created_at
                      AND ce2.event_type IN ('clock_out', 'break_start')
                  )
                  AND ce.created_at = (
                    SELECT MAX(ce3.created_at) FROM public.clock_events ce3
                    WHERE ce3.staff_id = v_staff.id AND ce3.created_at::date = d.day_date
                  )
              )
            ),
            'current_status', (
              SELECT ce.event_type
              FROM public.clock_events ce
              WHERE ce.staff_id = v_staff.id
                AND ce.created_at::date = d.day_date
              ORDER BY ce.created_at DESC LIMIT 1
            )
          )
        )
        FROM generate_series(p_week_start, v_week_end, '1 day'::interval) AS d(day_date)
      ), '[]'::jsonb)
    ) INTO v_grid;
    v_grid := v_grid || jsonb_build_array(v_grid);
  END LOOP;

  -- Actually build it properly
  SELECT COALESCE(jsonb_agg(
    jsonb_build_object(
      'staff_id', s.id,
      'display_name', s.display_name,
      'role', s.role,
      'current_status', (
        SELECT ce.event_type FROM public.clock_events ce
        WHERE ce.staff_id = s.id ORDER BY ce.created_at DESC LIMIT 1
      ),
      'active_since', (
        SELECT to_char(ce.created_at, 'YYYY-MM-DD"T"HH24:MI')
        FROM public.clock_events ce
        WHERE ce.staff_id = s.id AND ce.event_type IN ('clock_in', 'break_end')
        ORDER BY ce.created_at DESC LIMIT 1
      ),
      'days', COALESCE((
        SELECT jsonb_agg(
          jsonb_build_object(
            'date', to_char(d.day_date, 'YYYY-MM-DD'),
            'day_name', trim(to_char(d.day_date, 'Day')),
            'clock_in', (
              SELECT to_char(ce.created_at, 'HH12:MI AM')
              FROM public.clock_events ce
              WHERE ce.staff_id = s.id AND ce.event_type = 'clock_in'
                AND ce.created_at::date = d.day_date
              ORDER BY ce.created_at DESC LIMIT 1
            ),
            'clock_in_raw', (
              SELECT to_char(ce.created_at, 'YYYY-MM-DD"T"HH24:MI')
              FROM public.clock_events ce
              WHERE ce.staff_id = s.id AND ce.event_type = 'clock_in'
                AND ce.created_at::date = d.day_date
              ORDER BY ce.created_at DESC LIMIT 1
            ),
            'clock_out', (
              SELECT to_char(ce.created_at, 'HH12:MI AM')
              FROM public.clock_events ce
              WHERE ce.staff_id = s.id AND ce.event_type = 'clock_out'
                AND ce.created_at::date = d.day_date
              ORDER BY ce.created_at DESC LIMIT 1
            ),
            'clock_out_raw', (
              SELECT to_char(ce.created_at, 'YYYY-MM-DD"T"HH24:MI')
              FROM public.clock_events ce
              WHERE ce.staff_id = s.id AND ce.event_type = 'clock_out'
                AND ce.created_at::date = d.day_date
              ORDER BY ce.created_at DESC LIMIT 1
            ),
            'break_start', (
              SELECT to_char(ce.created_at, 'HH12:MI AM')
              FROM public.clock_events ce
              WHERE ce.staff_id = s.id AND ce.event_type = 'break_start'
                AND ce.created_at::date = d.day_date
              ORDER BY ce.created_at DESC LIMIT 1
            ),
            'break_end', (
              SELECT to_char(ce.created_at, 'HH12:MI AM')
              FROM public.clock_events ce
              WHERE ce.staff_id = s.id AND ce.event_type = 'break_end'
                AND ce.created_at::date = d.day_date
              ORDER BY ce.created_at DESC LIMIT 1
            ),
            'notes', (
              SELECT string_agg(ce.notes, ' | ')
              FROM public.clock_events ce
              WHERE ce.staff_id = s.id AND ce.created_at::date = d.day_date AND ce.notes <> ''
            ),
            'is_currently_in', (
              SELECT EXISTS (
                SELECT 1 FROM public.clock_events latest
                WHERE latest.staff_id = s.id
                  AND latest.created_at::date = d.day_date
                  AND latest.event_type IN ('clock_in', 'break_end')
                  AND latest.created_at = (
                    SELECT MAX(ce3.created_at) FROM public.clock_events ce3
                    WHERE ce3.staff_id = s.id AND ce3.created_at::date = d.day_date
                  )
              )
            ),
            'current_status', (
              SELECT ce.event_type FROM public.clock_events ce
              WHERE ce.staff_id = s.id AND ce.created_at::date = d.day_date
              ORDER BY ce.created_at DESC LIMIT 1
            )
          )
          ORDER BY d.day_date
        )
        FROM generate_series(p_week_start, v_week_end, '1 day'::interval) AS d(day_date)
      ), '[]'::jsonb)
    )
    ORDER BY s.display_name
  ), '[]'::jsonb)
  FROM public.staff_members s
  WHERE s.is_active = true
  INTO v_grid;

  RETURN v_grid;
END;
$function$;

-- Owner: manually clock a staff member in/out/break from the panel
CREATE OR REPLACE FUNCTION public.owner_clock_action(p_staff_id uuid, p_action text, p_note text DEFAULT ''::text)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public', 'extensions'
AS $function$
DECLARE v_staff_name text; v_last_event text;
BEGIN
IF NOT public.is_owner() THEN RAISE EXCEPTION 'Not authorized'; END IF;
IF p_action NOT IN ('clock_in', 'clock_out', 'break_start', 'break_end') THEN RAISE EXCEPTION 'Invalid action'; END IF;
SELECT display_name INTO v_staff_name FROM public.staff_members WHERE id = p_staff_id AND is_active = true;
IF v_staff_name IS NULL THEN RAISE EXCEPTION 'Staff member not found'; END IF;
SELECT event_type INTO v_last_event FROM public.clock_events WHERE staff_id = p_staff_id ORDER BY created_at DESC LIMIT 1;
IF p_action = 'clock_in' AND v_last_event IN ('clock_in', 'break_end') THEN RAISE EXCEPTION 'Already clocked in'; END IF;
IF p_action = 'clock_out' AND v_last_event NOT IN ('clock_in', 'break_end') THEN RAISE EXCEPTION 'Not clocked in'; END IF;
IF p_action = 'break_start' AND v_last_event <> 'clock_in' THEN RAISE EXCEPTION 'Not clocked in'; END IF;
IF p_action = 'break_end' AND v_last_event <> 'break_start' THEN RAISE EXCEPTION 'Not on break'; END IF;
INSERT INTO public.clock_events (staff_id, event_type, notes) VALUES (p_staff_id, p_action, left(coalesce(p_note, ''), 500));
INSERT INTO public.activity_logs (action, details, actor_user_id)
  VALUES ('Owner clock action', v_staff_name || ': ' || p_action || ' (by owner)', auth.uid());
RETURN true;
END;
$function$;

-- Manager: manually clock a staff member in/out/break from the manager panel
CREATE OR REPLACE FUNCTION public.staff_manager_clock_action(p_pin text, p_staff_id uuid, p_action text, p_note text DEFAULT ''::text)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public', 'extensions'
AS $function$
DECLARE v_manager public.staff_members; v_staff_name text; v_last_event text;
BEGIN
SELECT * INTO v_manager FROM public.staff_members WHERE is_active = true AND crypt(p_pin, pin_hash) = pin_hash LIMIT 1;
IF v_manager.id IS NULL OR v_manager.role <> 'manager' THEN RAISE EXCEPTION 'Not authorized'; END IF;
IF p_action NOT IN ('clock_in', 'clock_out', 'break_start', 'break_end') THEN RAISE EXCEPTION 'Invalid action'; END IF;
SELECT display_name INTO v_staff_name FROM public.staff_members WHERE id = p_staff_id AND is_active = true;
IF v_staff_name IS NULL THEN RAISE EXCEPTION 'Staff member not found'; END IF;
SELECT event_type INTO v_last_event FROM public.clock_events WHERE staff_id = p_staff_id ORDER BY created_at DESC LIMIT 1;
IF p_action = 'clock_in' AND v_last_event IN ('clock_in', 'break_end') THEN RAISE EXCEPTION 'Already clocked in'; END IF;
IF p_action = 'clock_out' AND v_last_event NOT IN ('clock_in', 'break_end') THEN RAISE EXCEPTION 'Not clocked in'; END IF;
IF p_action = 'break_start' AND v_last_event <> 'clock_in' THEN RAISE EXCEPTION 'Not clocked in'; END IF;
IF p_action = 'break_end' AND v_last_event <> 'break_start' THEN RAISE EXCEPTION 'Not on break'; END IF;
INSERT INTO public.clock_events (staff_id, p_action, notes) VALUES (p_staff_id, p_action, left(coalesce(p_note, ''), 500));
INSERT INTO public.activity_logs (action, details, actor_user_id)
  VALUES ('Manager clock action', v_staff_name || ': ' || p_action || ' (by ' || v_manager.display_name || ')', null);
RETURN true;
END;
$function$;

-- Manager: get week clock grid (same as owner but verified via pin)
CREATE OR REPLACE FUNCTION public.staff_manager_week_grid(p_pin text, p_week_start date)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public', 'extensions'
AS $function$
DECLARE v_manager public.staff_members; v_week_end date := p_week_start + 6; v_grid jsonb;
BEGIN
SELECT * INTO v_manager FROM public.staff_members WHERE is_active = true AND crypt(p_pin, pin_hash) = pin_hash LIMIT 1;
IF v_manager.id IS NULL OR v_manager.role <> 'manager' THEN RAISE EXCEPTION 'Not authorized'; END IF;

SELECT COALESCE(jsonb_agg(
  jsonb_build_object(
    'staff_id', s.id,
    'display_name', s.display_name,
    'role', s.role,
    'current_status', (
      SELECT ce.event_type FROM public.clock_events ce WHERE ce.staff_id = s.id ORDER BY ce.created_at DESC LIMIT 1
    ),
    'active_since', (
      SELECT to_char(ce.created_at, 'YYYY-MM-DD"T"HH24:MI')
      FROM public.clock_events ce WHERE ce.staff_id = s.id AND ce.event_type IN ('clock_in','break_end')
      ORDER BY ce.created_at DESC LIMIT 1
    ),
    'days', COALESCE((
      SELECT jsonb_agg(
        jsonb_build_object(
          'date', to_char(d.day_date, 'YYYY-MM-DD'),
          'day_name', trim(to_char(d.day_date, 'Day')),
          'clock_in', (
            SELECT to_char(ce.created_at, 'HH12:MI AM') FROM public.clock_events ce
            WHERE ce.staff_id = s.id AND ce.event_type = 'clock_in' AND ce.created_at::date = d.day_date
            ORDER BY ce.created_at DESC LIMIT 1
          ),
          'clock_in_raw', (
            SELECT to_char(ce.created_at, 'YYYY-MM-DD"T"HH24:MI') FROM public.clock_events ce
            WHERE ce.staff_id = s.id AND ce.event_type = 'clock_in' AND ce.created_at::date = d.day_date
            ORDER BY ce.created_at DESC LIMIT 1
          ),
          'clock_out', (
            SELECT to_char(ce.created_at, 'HH12:MI AM') FROM public.clock_events ce
            WHERE ce.staff_id = s.id AND ce.event_type = 'clock_out' AND ce.created_at::date = d.day_date
            ORDER BY ce.created_at DESC LIMIT 1
          ),
          'clock_out_raw', (
            SELECT to_char(ce.created_at, 'YYYY-MM-DD"T"HH24:MI') FROM public.clock_events ce
            WHERE ce.staff_id = s.id AND ce.event_type = 'clock_out' AND ce.created_at::date = d.day_date
            ORDER BY ce.created_at DESC LIMIT 1
          ),
          'break_start', (
            SELECT to_char(ce.created_at, 'HH12:MI AM') FROM public.clock_events ce
            WHERE ce.staff_id = s.id AND ce.event_type = 'break_start' AND ce.created_at::date = d.day_date
            ORDER BY ce.created_at DESC LIMIT 1
          ),
          'break_end', (
            SELECT to_char(ce.created_at, 'HH12:MI AM') FROM public.clock_events ce
            WHERE ce.staff_id = s.id AND ce.event_type = 'break_end' AND ce.created_at::date = d.day_date
            ORDER BY ce.created_at DESC LIMIT 1
          ),
          'notes', (
            SELECT string_agg(ce.notes, ' | ') FROM public.clock_events ce
            WHERE ce.staff_id = s.id AND ce.created_at::date = d.day_date AND ce.notes <> ''
          ),
          'is_currently_in', (
            SELECT EXISTS (
              SELECT 1 FROM public.clock_events latest
              WHERE latest.staff_id = s.id AND latest.created_at::date = d.day_date
                AND latest.event_type IN ('clock_in','break_end')
                AND latest.created_at = (SELECT MAX(ce3.created_at) FROM public.clock_events ce3 WHERE ce3.staff_id = s.id AND ce3.created_at::date = d.day_date)
            )
          ),
          'current_status', (
            SELECT ce.event_type FROM public.clock_events ce
            WHERE ce.staff_id = s.id AND ce.created_at::date = d.day_date ORDER BY ce.created_at DESC LIMIT 1
          )
        ) ORDER BY d.day_date
      ) FROM generate_series(p_week_start, v_week_end, '1 day'::interval) AS d(day_date)
    ), '[]'::jsonb)
  ) ORDER BY s.display_name
), '[]'::jsonb)
FROM public.staff_members s WHERE s.is_active = true
INTO v_grid;

RETURN v_grid;
END;
$function$;

-- Grant execute on new functions
GRANT EXECUTE ON FUNCTION public.owner_week_clock_grid TO authenticated;
GRANT EXECUTE ON FUNCTION public.owner_clock_action TO authenticated;
GRANT EXECUTE ON FUNCTION public.staff_manager_clock_action TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.staff_manager_week_grid TO anon, authenticated;

-- Add manager SELECT policy on contact_messages
DROP POLICY IF EXISTS "Managers can read contact messages" ON public.contact_messages;
CREATE POLICY "Managers can read contact messages" ON public.contact_messages
  FOR SELECT TO authenticated USING (public.is_manager());

-- Add manager SELECT policy on time_off_requests
DROP POLICY IF EXISTS "Managers can read time off requests" ON public.time_off_requests;
CREATE POLICY "Managers can read time off requests" ON public.time_off_requests
  FOR SELECT TO authenticated USING (public.is_manager());

-- Add manager update policy on time_off_requests (for approve/deny)
DROP POLICY IF EXISTS "Managers can update time off requests" ON public.time_off_requests;
CREATE POLICY "Managers can update time off requests" ON public.time_off_requests
  FOR UPDATE TO authenticated USING (public.is_manager()) WITH CHECK (public.is_manager());
