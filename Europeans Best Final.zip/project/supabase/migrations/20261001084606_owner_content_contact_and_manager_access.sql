/*
# Run automatic clock-out from owner time view

1. New function
- `owner_auto_clock_out_staff` checks the owner session and runs the 9:00 PM close before the owner reviews staff time.

2. Security
- Anonymous users and staff sessions cannot call this owner-only helper.
*/

CREATE OR REPLACE FUNCTION public.owner_auto_clock_out_staff()
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.is_owner() THEN RAISE EXCEPTION 'Not authorized'; END IF;
  RETURN public.auto_clock_out_staff();
END;
$$;

REVOKE EXECUTE ON FUNCTION public.owner_auto_clock_out_staff() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.owner_auto_clock_out_staff() TO authenticated;