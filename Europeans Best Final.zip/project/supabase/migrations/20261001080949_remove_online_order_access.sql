/*
# Remove order data from staff sessions

1. Security and behavior
- `staff_dashboard` no longer returns any order or inquiry data.
- Staff sessions now return only staff identity, time status, clock history, and permitted schedules.
- Existing order history remains available to the owner through its stored database records.
*/

CREATE OR REPLACE FUNCTION public.staff_dashboard(p_pin text)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_staff public.staff_members;
  v_last_event text;
  v_active_since timestamptz;
  v_events jsonb;
  v_schedules jsonb;
BEGIN
  IF p_pin IS NULL OR p_pin !~ '^[0-9]{4,12}$' THEN RAISE EXCEPTION 'Invalid kiosk entry'; END IF;
  SELECT * INTO v_staff FROM public.staff_members WHERE is_active = true AND crypt(p_pin, pin_hash) = pin_hash LIMIT 1;
  IF v_staff.id IS NULL THEN RAISE EXCEPTION 'Invalid kiosk entry'; END IF;
  SELECT event_type, created_at INTO v_last_event, v_active_since FROM public.clock_events WHERE staff_id = v_staff.id ORDER BY created_at DESC LIMIT 1;
  IF v_last_event NOT IN ('clock_in', 'break_end') THEN v_active_since := NULL; END IF;
  SELECT COALESCE(jsonb_agg(jsonb_build_object('event_type', event_type, 'created_at', created_at, 'notes', notes) ORDER BY created_at DESC), '[]'::jsonb)
  INTO v_events FROM (SELECT event_type, created_at, notes FROM public.clock_events WHERE staff_id = v_staff.id ORDER BY created_at DESC LIMIT 20) history;
  SELECT COALESCE(jsonb_agg(jsonb_build_object('date', schedule_date, 'start_time', start_time, 'end_time', end_time, 'notes', notes) ORDER BY schedule_date), '[]'::jsonb)
  INTO v_schedules FROM public.staff_schedules WHERE staff_id = v_staff.id AND schedule_date >= current_date - 1;
  RETURN jsonb_build_object(
    'staff', jsonb_build_object('id', v_staff.id, 'display_name', v_staff.display_name, 'role', v_staff.role, 'can_view_calendar', v_staff.can_view_calendar),
    'current_status', v_last_event,
    'active_since', v_active_since,
    'events', v_events,
    'schedules', CASE WHEN v_staff.can_view_calendar THEN v_schedules ELSE '[]'::jsonb END
  );
END;
$$;