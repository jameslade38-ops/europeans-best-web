/*
# Tighten owner-only function permissions

1. Security changes
- Anonymous visitors can no longer call `is_owner` or `owner_update_clock_event`.
- Signed-in owners retain the required control-panel behavior.
- Staff PIN functions remain available only where the kiosk requires them.
*/

REVOKE EXECUTE ON FUNCTION public.is_owner() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.is_owner() TO authenticated;
REVOKE EXECUTE ON FUNCTION public.owner_update_clock_event(uuid, text, timestamptz, text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.owner_update_clock_event(uuid, text, timestamptz, text) TO authenticated;