/*
# Fix gen_random_uuid search_path and add Google Business account storage

1. Fix
- contact_messages.id default used gen_random_uuid() which lives in extensions schema.
- Schema-qualify the default to extensions.gen_random_uuid() for reliability.

2. New table
- review_settings: stores the Google Business profile URL for the reviews tracker.
- Owner-only access via is_owner() RLS.
*/

ALTER TABLE public.contact_messages ALTER COLUMN id SET DEFAULT extensions.gen_random_uuid();

CREATE TABLE IF NOT EXISTS public.review_settings (
  setting_key text PRIMARY KEY DEFAULT 'main' CHECK (setting_key = 'main'),
  google_business_url text NOT NULL DEFAULT '',
  updated_at timestamptz NOT NULL DEFAULT now()
);

INSERT INTO public.review_settings (setting_key) VALUES ('main') ON CONFLICT (setting_key) DO NOTHING;

ALTER TABLE public.review_settings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Owners can read review settings" ON public.review_settings;
CREATE POLICY "Owners can read review settings" ON public.review_settings FOR SELECT TO authenticated USING (public.is_owner());
DROP POLICY IF EXISTS "Owners can insert review settings" ON public.review_settings;
CREATE POLICY "Owners can insert review settings" ON public.review_settings FOR INSERT TO authenticated WITH CHECK (public.is_owner());
DROP POLICY IF EXISTS "Owners can update review settings" ON public.review_settings;
CREATE POLICY "Owners can update review settings" ON public.review_settings FOR UPDATE TO authenticated USING (public.is_owner()) WITH CHECK (public.is_owner());
DROP POLICY IF EXISTS "Owners can delete review settings" ON public.review_settings;
CREATE POLICY "Owners can delete review settings" ON public.review_settings FOR DELETE TO authenticated USING (public.is_owner());