/*
# Owner controls, contact messages, and manager time access

1. Modified tables
- `owner_accounts`: adds `display_name` for the owner-facing control panel name.
- `staff_members`: keeps manager role access and supports two preview accounts.

2. New tables
- `site_settings`: owner-controlled visibility for the Join the Family button and Seasonal Bakery navigation item.
- `contact_messages`: public contact form submissions, private to owner and authorized managers.

3. New functions
- `auto_clock_out_staff`: adds a 9:00 PM automatic clock-out with a visible note when the app checks timekeeping after the cutoff.
- `staff_manager_dashboard`: returns all staff time entries to an authenticated manager session, without PINs or customer order data.
- `staff_manager_update_clock_event`: allows a manager or owner to correct any staff time entry.

4. Security
- Public visitors may insert contact messages but cannot read them.
- Site settings and owner display name are owner-managed.
- Manager time access is checked inside SECURITY DEFINER functions using the supplied staff PIN and stored manager role.
- Existing staff time, menu, and customer data remains intact.
*/

ALTER TABLE public.owner_accounts ADD COLUMN IF NOT EXISTS display_name text NOT NULL DEFAULT 'The Family';

CREATE TABLE IF NOT EXISTS public.site_settings (
  setting_key text PRIMARY KEY DEFAULT 'main' CHECK (setting_key = 'main'),
  join_family_enabled boolean NOT NULL DEFAULT true,
  seasonal_nav_enabled boolean NOT NULL DEFAULT true,
  updated_at timestamptz NOT NULL DEFAULT now()
);

INSERT INTO public.site_settings (setting_key) VALUES ('main') ON CONFLICT (setting_key) DO NOTHING;

CREATE TABLE IF NOT EXISTS public.contact_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name text NOT NULL CHECK (char_length(full_name) BETWEEN 2 AND 120),
  email text NOT NULL CHECK (char_length(email) BETWEEN 5 AND 254),
  phone text CHECK (phone IS NULL OR char_length(phone) BETWEEN 7 AND 30),
  message text NOT NULL CHECK (char_length(message) BETWEEN 5 AND 4000),
  status text NOT NULL DEFAULT 'new' CHECK (status IN ('new', 'read', 'replied', 'archived')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.site_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.contact_messages ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Public can read site settings" ON public.site_settings;
CREATE POLICY "Public can read site settings" ON public.site_settings FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "Owners can insert site settings" ON public.site_settings;
CREATE POLICY "Owners can insert site settings" ON public.site_settings FOR INSERT TO authenticated WITH CHECK (public.is_owner());
DROP POLICY IF EXISTS "Owners can update site settings" ON public.site_settings;
CREATE POLICY "Owners can update site settings" ON public.site_settings FOR UPDATE TO authenticated USING (public.is_owner()) WITH CHECK (public.is_owner());
DROP POLICY IF EXISTS "Owners can delete site settings" ON public.site_settings;
CREATE POLICY "Owners can delete site settings" ON public.site_settings FOR DELETE TO authenticated USING (public.is_owner());

DROP POLICY IF EXISTS "Owners can read contact messages" ON public.contact_messages;
CREATE POLICY "Owners can read contact messages" ON public.contact_messages FOR SELECT TO authenticated USING (public.is_owner());
DROP POLICY IF EXISTS "Visitors can send contact messages" ON public.contact_messages;
CREATE POLICY "Visitors can send contact messages" ON public.contact_messages FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "Owners can update contact messages" ON public.contact_messages;
CREATE POLICY "Owners can update contact messages" ON public.contact_messages FOR UPDATE TO authenticated USING (public.is_owner()) WITH CHECK (public.is_owner());
DROP POLICY IF EXISTS "Owners can delete contact messages" ON public.contact_messages;
CREATE POLICY "Owners can delete contact messages" ON public.contact_messages FOR DELETE TO authenticated USING (public.is_owner());

CREATE OR REPLACE FUNCTION public.auto_clock_out_staff()
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE v_local timestamp; v_cutoff timestamptz; v_count integer;
BEGIN
  v_local := timezone('America/New_York', now());
  v_cutoff := ((CASE WHEN v_local::time >= time '21:00' THEN v_local::date ELSE v_local::date - 1 END) + time '21:00') AT TIME ZONE 'America/New_York';
  INSERT INTO public.clock_events (staff_id, event_type, created_at, notes)
  SELECT staff.id, 'clock_out', v_cutoff, 'Automatically clocked out at 9:00 PM.'
  FROM public.staff_members staff
  WHERE staff.is_active = true
    AND (SELECT event_type FROM public.clock_events WHERE staff_id = staff.id ORDER BY created_at DESC LIMIT 1) IN ('clock_in', 'break_end')
    AND (SELECT created_at FROM public.clock_events WHERE staff_id = staff.id ORDER BY created_at DESC LIMIT 1) < v_cutoff;
  GET DIAGNOSTICS v_count = ROW_COUNT;
  RETURN v_count;
END;
$$;

CREATE OR REPLACE FUNCTION public.staff_manager_dashboard(p_pin text)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE v_staff public.staff_members; v_events jsonb;
BEGIN
  PERFORM public.auto_clock_out_staff();
  SELECT * INTO v_staff FROM public.staff_members WHERE is_active = true AND crypt(p_pin, pin_hash) = pin_hash LIMIT 1;
  IF v_staff.id IS NULL OR v_staff.role <> 'manager' THEN RAISE EXCEPTION 'Not authorized'; END IF;
  SELECT COALESCE(jsonb_agg(jsonb_build_object('id', events.id, 'staff_id', events.staff_id, 'display_name', staff.display_name, 'event_type', events.event_type, 'created_at', events.created_at, 'notes', events.notes) ORDER BY events.created_at DESC), '[]'::jsonb)
  INTO v_events FROM public.clock_events events JOIN public.staff_members staff ON staff.id = events.staff_id LIMIT 100;
  RETURN jsonb_build_object('staff', jsonb_build_object('display_name', v_staff.display_name, 'role', v_staff.role), 'events', v_events);
END;
$$;

CREATE OR REPLACE FUNCTION public.staff_manager_update_clock_event(p_pin text, p_event_id uuid, p_event_type text, p_created_at timestamptz, p_note text DEFAULT '')
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE v_staff public.staff_members;
BEGIN
  SELECT * INTO v_staff FROM public.staff_members WHERE is_active = true AND crypt(p_pin, pin_hash) = pin_hash LIMIT 1;
  IF v_staff.id IS NULL OR v_staff.role <> 'manager' THEN RAISE EXCEPTION 'Not authorized'; END IF;
  IF p_event_type NOT IN ('clock_in', 'clock_out', 'break_start', 'break_end') THEN RAISE EXCEPTION 'Invalid event'; END IF;
  UPDATE public.clock_events SET event_type = p_event_type, created_at = p_created_at, notes = left(coalesce(p_note, ''), 500) WHERE id = p_event_id;
  RETURN FOUND;
END;
$$;

CREATE OR REPLACE FUNCTION public.staff_dashboard(p_pin text)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE v_staff public.staff_members; v_last_event text; v_active_since timestamptz; v_events jsonb; v_schedules jsonb;
BEGIN
  PERFORM public.auto_clock_out_staff();
  IF p_pin IS NULL OR p_pin !~ '^[0-9]{4,12}$' THEN RAISE EXCEPTION 'Invalid kiosk entry'; END IF;
  SELECT * INTO v_staff FROM public.staff_members WHERE is_active = true AND crypt(p_pin, pin_hash) = pin_hash LIMIT 1;
  IF v_staff.id IS NULL THEN RAISE EXCEPTION 'Invalid kiosk entry'; END IF;
  SELECT event_type, created_at INTO v_last_event, v_active_since FROM public.clock_events WHERE staff_id = v_staff.id ORDER BY created_at DESC LIMIT 1;
  IF v_last_event NOT IN ('clock_in', 'break_end') THEN v_active_since := NULL; END IF;
  SELECT COALESCE(jsonb_agg(jsonb_build_object('event_type', event_type, 'created_at', created_at, 'notes', notes) ORDER BY created_at DESC), '[]'::jsonb) INTO v_events FROM (SELECT event_type, created_at, notes FROM public.clock_events WHERE staff_id = v_staff.id ORDER BY created_at DESC LIMIT 20) history;
  SELECT COALESCE(jsonb_agg(jsonb_build_object('date', schedule_date, 'start_time', start_time, 'end_time', end_time, 'notes', notes) ORDER BY schedule_date), '[]'::jsonb) INTO v_schedules FROM public.staff_schedules WHERE staff_id = v_staff.id AND schedule_date >= current_date - 1;
  RETURN jsonb_build_object('staff', jsonb_build_object('id', v_staff.id, 'display_name', v_staff.display_name, 'role', v_staff.role, 'can_view_calendar', v_staff.can_view_calendar), 'current_status', v_last_event, 'active_since', v_active_since, 'events', v_events, 'schedules', CASE WHEN v_staff.can_view_calendar THEN v_schedules ELSE '[]'::jsonb END);
END;
$$;

CREATE OR REPLACE FUNCTION public.staff_sign_in(p_name text, p_pin text)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE v_staff public.staff_members; v_last_event text;
BEGIN
  PERFORM public.auto_clock_out_staff();
  IF p_name IS NULL OR char_length(trim(p_name)) < 2 OR p_pin IS NULL OR p_pin !~ '^[0-9]{4,12}$' THEN RAISE EXCEPTION 'Invalid kiosk entry'; END IF;
  SELECT * INTO v_staff FROM public.staff_members WHERE is_active = true AND split_part(lower(trim(display_name)), ' ', 1) = lower(trim(p_name)) AND crypt(p_pin, pin_hash) = pin_hash LIMIT 1;
  IF v_staff.id IS NULL THEN RAISE EXCEPTION 'Invalid kiosk entry'; END IF;
  SELECT event_type INTO v_last_event FROM public.clock_events WHERE staff_id = v_staff.id ORDER BY created_at DESC LIMIT 1;
  IF v_last_event IS NULL OR v_last_event = 'clock_out' THEN INSERT INTO public.clock_events (staff_id, event_type) VALUES (v_staff.id, 'clock_in'); END IF;
  RETURN public.staff_dashboard(p_pin);
END;
$$;

CREATE OR REPLACE FUNCTION public.staff_clock_action(p_pin text, p_action text, p_note text DEFAULT '')
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE v_staff public.staff_members; v_last_event text;
BEGIN
  PERFORM public.auto_clock_out_staff();
  SELECT * INTO v_staff FROM public.staff_members WHERE is_active = true AND crypt(p_pin, pin_hash) = pin_hash LIMIT 1;
  IF v_staff.id IS NULL THEN RAISE EXCEPTION 'Invalid kiosk entry'; END IF;
  IF p_action NOT IN ('clock_in', 'clock_out', 'break_start', 'break_end') THEN RAISE EXCEPTION 'Invalid clock action'; END IF;
  SELECT event_type INTO v_last_event FROM public.clock_events WHERE staff_id = v_staff.id ORDER BY created_at DESC LIMIT 1;
  IF p_action = 'clock_in' AND v_last_event IN ('clock_in', 'break_end') THEN RAISE EXCEPTION 'Already clocked in'; END IF;
  IF p_action = 'clock_out' AND v_last_event NOT IN ('clock_in', 'break_end') THEN RAISE EXCEPTION 'Not clocked in'; END IF;
  IF p_action = 'break_start' AND v_last_event <> 'clock_in' THEN RAISE EXCEPTION 'Not clocked in'; END IF;
  IF p_action = 'break_end' AND v_last_event <> 'break_start' THEN RAISE EXCEPTION 'Not on break'; END IF;
  INSERT INTO public.clock_events (staff_id, event_type, notes) VALUES (v_staff.id, p_action, left(coalesce(p_note, ''), 500));
  RETURN public.staff_dashboard(p_pin);
END;
$$;

REVOKE EXECUTE ON FUNCTION public.auto_clock_out_staff() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.staff_manager_dashboard(text) FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.staff_manager_update_clock_event(text, uuid, text, timestamptz, text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.staff_manager_dashboard(text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.staff_manager_update_clock_event(text, uuid, text, timestamptz, text) TO anon, authenticated;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM public.staff_members WHERE lower(display_name) = 'temporary manager') THEN
    INSERT INTO public.staff_members (display_name, role, pin_hash, is_active, can_view_calendar)
    VALUES ('Temporary Manager', 'manager', crypt('1357', gen_salt('bf')), true, true);
  ELSE
    UPDATE public.staff_members SET role = 'manager', is_active = true, pin_hash = crypt('1357', gen_salt('bf')) WHERE lower(display_name) = 'temporary manager';
  END IF;
  UPDATE public.staff_members SET is_active = true, pin_hash = crypt('2468', gen_salt('bf')) WHERE lower(display_name) = 'temporary';
END $$;