/*
# Delete staff member fully, add event IDs to grid RPCs, schedule upsert multi-day

## 1. New Functions
- `owner_delete_staff_member(p_staff_id uuid)` — permanently deletes a staff member and all
  their related data (clock_events, staff_schedules, time_off_requests). Hard delete, not soft.
  Owner-only (SECURITY DEFINER, is_owner check).
- `owner_save_schedule(p_staff_ids uuid[], p_start_date date, p_end_date date, p_start_time text, p_end_time text, p_notes text)` —
  creates shifts for multiple staff members across a date range in one call. Owner-only.
- `owner_update_schedule(p_schedule_id uuid, p_start_time text, p_end_time text, p_notes text)` —
  updates a single existing schedule shift. Owner-only.

## 2. Modified Functions
- `owner_week_clock_grid` — each day cell now includes `clock_in_event_id` and `clock_out_event_id`
  so the frontend can let the owner edit the exact time by calling owner_update_clock_event.
- `staff_manager_week_grid` — same change, includes event IDs.

## 3. Security
- All functions are SECURITY DEFINER with locked search_path.
- Owner functions check is_owner().
*/

-- ── Owner: hard-delete a staff member and all related data ──
CREATE OR REPLACE FUNCTION public.owner_delete_staff_member(p_staff_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public', 'extensions'
AS $function$
DECLARE v_name text;
BEGIN
IF NOT public.is_owner() THEN RAISE EXCEPTION 'Not authorized'; END IF;
SELECT display_name INTO v_name FROM public.staff_members WHERE id = p_staff_id;
IF v_name IS NULL THEN RAISE EXCEPTION 'Staff member not found'; END IF;
DELETE FROM public.clock_events WHERE staff_id = p_staff_id;
DELETE FROM public.staff_schedules WHERE staff_id = p_staff_id;
DELETE FROM public.time_off_requests WHERE staff_id = p_staff_id;
DELETE FROM public.staff_members WHERE id = p_staff_id;
INSERT INTO public.activity_logs (action, details, actor_user_id)
  VALUES ('Deleted staff member', v_name || ' and all their data removed', auth.uid());
RETURN true;
END;
$function$;

-- ── Owner: save schedule for multiple staff across a date range ──
CREATE OR REPLACE FUNCTION public.owner_save_schedule(p_staff_ids uuid[], p_start_date date, p_end_date date, p_start_time text, p_end_time text, p_notes text DEFAULT ''::text)
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public', 'extensions'
AS $function$
DECLARE v_count integer := 0; v_date date; v_staff_id uuid; v_name text;
BEGIN
IF NOT public.is_owner() THEN RAISE EXCEPTION 'Not authorized'; END IF;
IF p_start_date IS NULL OR p_end_date IS NULL OR p_end_date < p_start_date THEN RAISE EXCEPTION 'Invalid date range'; END IF;
IF array_length(p_staff_ids, 1) IS NULL OR array_length(p_staff_ids, 1) = 0 THEN RAISE EXCEPTION 'No staff selected'; END IF;
v_date := p_start_date;
WHILE v_date <= p_end_date LOOP
  FOREACH v_staff_id IN ARRAY p_staff_ids LOOP
    SELECT display_name INTO v_name FROM public.staff_members WHERE id = v_staff_id AND is_active = true;
    IF v_name IS NOT NULL THEN
      INSERT INTO public.staff_schedules (staff_id, schedule_date, start_time, end_time, notes)
        VALUES (v_staff_id, v_date, p_start_time, p_end_time, left(coalesce(p_notes, ''), 500))
        ON CONFLICT (staff_id, schedule_date) DO UPDATE SET start_time = p_start_time, end_time = p_end_time, notes = left(coalesce(p_notes, ''), 500), updated_at = now();
      v_count := v_count + 1;
    END IF;
  END LOOP;
  v_date := v_date + 1;
END LOOP;
INSERT INTO public.activity_logs (action, details, actor_user_id)
  VALUES ('Saved schedule', v_count || ' shift(s) saved', auth.uid());
RETURN v_count;
END;
$function$;

-- ── Owner: update schedule shift ──
CREATE OR REPLACE FUNCTION public.owner_update_schedule(p_schedule_id uuid, p_start_time text, p_end_time text, p_notes text DEFAULT ''::text)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public', 'extensions'
AS $function$
BEGIN
IF NOT public.is_owner() THEN RAISE EXCEPTION 'Not authorized'; END IF;
UPDATE public.staff_schedules SET start_time = p_start_time, end_time = p_end_time, notes = left(coalesce(p_notes, ''), 500), updated_at = now() WHERE id = p_schedule_id;
RETURN true;
END;
$function$;

-- Add a unique constraint on staff_schedules (staff_id, schedule_date) for upsert to work
CREATE UNIQUE INDEX IF NOT EXISTS staff_schedules_staff_date_unique ON public.staff_schedules (staff_id, schedule_date);

-- Grant owner update/delete on staff_schedules
GRANT UPDATE, DELETE ON public.staff_schedules TO authenticated;

-- ── Owner week clock grid with event IDs ──
CREATE OR REPLACE FUNCTION public.owner_week_clock_grid(p_week_start date)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public', 'extensions'
AS $function$
DECLARE v_week_end date := p_week_start + 6; v_grid jsonb;
BEGIN
IF NOT public.is_owner() THEN RAISE EXCEPTION 'Not authorized'; END IF;

SELECT COALESCE(jsonb_agg(
  jsonb_build_object(
    'staff_id', s.id,
    'display_name', s.display_name,
    'role', s.role,
    'current_status', (
      SELECT ce.event_type FROM public.clock_events ce WHERE ce.staff_id = s.id ORDER BY ce.created_at DESC LIMIT 1
    ),
    'active_since', (
      SELECT to_char(ce.created_at, 'YYYY-MM-DD"T"HH24:MI')
      FROM public.clock_events ce WHERE ce.staff_id = s.id AND ce.event_type IN ('clock_in','break_end')
      ORDER BY ce.created_at DESC LIMIT 1
    ),
    'days', COALESCE((
      SELECT jsonb_agg(
        jsonb_build_object(
          'date', to_char(d.day_date, 'YYYY-MM-DD'),
          'day_name', trim(to_char(d.day_date, 'Day')),
          'clock_in', (
            SELECT to_char(ce.created_at, 'HH12:MI AM') FROM public.clock_events ce
            WHERE ce.staff_id = s.id AND ce.event_type = 'clock_in' AND ce.created_at::date = d.day_date
            ORDER BY ce.created_at DESC LIMIT 1
          ),
          'clock_in_raw', (
            SELECT to_char(ce.created_at, 'YYYY-MM-DD"T"HH24:MI') FROM public.clock_events ce
            WHERE ce.staff_id = s.id AND ce.event_type = 'clock_in' AND ce.created_at::date = d.day_date
            ORDER BY ce.created_at DESC LIMIT 1
          ),
          'clock_in_event_id', (
            SELECT ce.id FROM public.clock_events ce
            WHERE ce.staff_id = s.id AND ce.event_type = 'clock_in' AND ce.created_at::date = d.day_date
            ORDER BY ce.created_at DESC LIMIT 1
          ),
          'clock_out', (
            SELECT to_char(ce.created_at, 'HH12:MI AM') FROM public.clock_events ce
            WHERE ce.staff_id = s.id AND ce.event_type = 'clock_out' AND ce.created_at::date = d.day_date
            ORDER BY ce.created_at DESC LIMIT 1
          ),
          'clock_out_raw', (
            SELECT to_char(ce.created_at, 'YYYY-MM-DD"T"HH24:MI') FROM public.clock_events ce
            WHERE ce.staff_id = s.id AND ce.event_type = 'clock_out' AND ce.created_at::date = d.day_date
            ORDER BY ce.created_at DESC LIMIT 1
          ),
          'clock_out_event_id', (
            SELECT ce.id FROM public.clock_events ce
            WHERE ce.staff_id = s.id AND ce.event_type = 'clock_out' AND ce.created_at::date = d.day_date
            ORDER BY ce.created_at DESC LIMIT 1
          ),
          'break_start', (
            SELECT to_char(ce.created_at, 'HH12:MI AM') FROM public.clock_events ce
            WHERE ce.staff_id = s.id AND ce.event_type = 'break_start' AND ce.created_at::date = d.day_date
            ORDER BY ce.created_at DESC LIMIT 1
          ),
          'break_end', (
            SELECT to_char(ce.created_at, 'HH12:MI AM') FROM public.clock_events ce
            WHERE ce.staff_id = s.id AND ce.event_type = 'break_end' AND ce.created_at::date = d.day_date
            ORDER BY ce.created_at DESC LIMIT 1
          ),
          'notes', (
            SELECT string_agg(ce.notes, ' | ') FROM public.clock_events ce
            WHERE ce.staff_id = s.id AND ce.created_at::date = d.day_date AND ce.notes <> ''
          ),
          'is_currently_in', (
            SELECT EXISTS (
              SELECT 1 FROM public.clock_events latest
              WHERE latest.staff_id = s.id AND latest.created_at::date = d.day_date
                AND latest.event_type IN ('clock_in','break_end')
                AND latest.created_at = (SELECT MAX(ce3.created_at) FROM public.clock_events ce3 WHERE ce3.staff_id = s.id AND ce3.created_at::date = d.day_date)
            )
          ),
          'current_status', (
            SELECT ce.event_type FROM public.clock_events ce
            WHERE ce.staff_id = s.id AND ce.created_at::date = d.day_date ORDER BY ce.created_at DESC LIMIT 1
          )
        ) ORDER BY d.day_date
      ) FROM generate_series(p_week_start, v_week_end, '1 day'::interval) AS d(day_date)
    ), '[]'::jsonb)
  ) ORDER BY s.display_name
), '[]'::jsonb)
FROM public.staff_members s WHERE s.is_active = true
INTO v_grid;

RETURN v_grid;
END;
$function$;

-- ── Manager week clock grid with event IDs ──
CREATE OR REPLACE FUNCTION public.staff_manager_week_grid(p_pin text, p_week_start date)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public', 'extensions'
AS $function$
DECLARE v_manager public.staff_members; v_week_end date := p_week_start + 6; v_grid jsonb;
BEGIN
SELECT * INTO v_manager FROM public.staff_members WHERE is_active = true AND crypt(p_pin, pin_hash) = pin_hash LIMIT 1;
IF v_manager.id IS NULL OR v_manager.role <> 'manager' THEN RAISE EXCEPTION 'Not authorized'; END IF;

SELECT COALESCE(jsonb_agg(
  jsonb_build_object(
    'staff_id', s.id,
    'display_name', s.display_name,
    'role', s.role,
    'current_status', (
      SELECT ce.event_type FROM public.clock_events ce WHERE ce.staff_id = s.id ORDER BY ce.created_at DESC LIMIT 1
    ),
    'active_since', (
      SELECT to_char(ce.created_at, 'YYYY-MM-DD"T"HH24:MI')
      FROM public.clock_events ce WHERE ce.staff_id = s.id AND ce.event_type IN ('clock_in','break_end')
      ORDER BY ce.created_at DESC LIMIT 1
    ),
    'days', COALESCE((
      SELECT jsonb_agg(
        jsonb_build_object(
          'date', to_char(d.day_date, 'YYYY-MM-DD'),
          'day_name', trim(to_char(d.day_date, 'Day')),
          'clock_in', (
            SELECT to_char(ce.created_at, 'HH12:MI AM') FROM public.clock_events ce
            WHERE ce.staff_id = s.id AND ce.event_type = 'clock_in' AND ce.created_at::date = d.day_date
            ORDER BY ce.created_at DESC LIMIT 1
          ),
          'clock_in_raw', (
            SELECT to_char(ce.created_at, 'YYYY-MM-DD"T"HH24:MI') FROM public.clock_events ce
            WHERE ce.staff_id = s.id AND ce.event_type = 'clock_in' AND ce.created_at::date = d.day_date
            ORDER BY ce.created_at DESC LIMIT 1
          ),
          'clock_in_event_id', (
            SELECT ce.id FROM public.clock_events ce
            WHERE ce.staff_id = s.id AND ce.event_type = 'clock_in' AND ce.created_at::date = d.day_date
            ORDER BY ce.created_at DESC LIMIT 1
          ),
          'clock_out', (
            SELECT to_char(ce.created_at, 'HH12:MI AM') FROM public.clock_events ce
            WHERE ce.staff_id = s.id AND ce.event_type = 'clock_out' AND ce.created_at::date = d.day_date
            ORDER BY ce.created_at DESC LIMIT 1
          ),
          'clock_out_raw', (
            SELECT to_char(ce.created_at, 'YYYY-MM-DD"T"HH24:MI') FROM public.clock_events ce
            WHERE ce.staff_id = s.id AND ce.event_type = 'clock_out' AND ce.created_at::date = d.day_date
            ORDER BY ce.created_at DESC LIMIT 1
          ),
          'clock_out_event_id', (
            SELECT ce.id FROM public.clock_events ce
            WHERE ce.staff_id = s.id AND ce.event_type = 'clock_out' AND ce.created_at::date = d.day_date
            ORDER BY ce.created_at DESC LIMIT 1
          ),
          'break_start', (
            SELECT to_char(ce.created_at, 'HH12:MI AM') FROM public.clock_events ce
            WHERE ce.staff_id = s.id AND ce.event_type = 'break_start' AND ce.created_at::date = d.day_date
            ORDER BY ce.created_at DESC LIMIT 1
          ),
          'break_end', (
            SELECT to_char(ce.created_at, 'HH12:MI AM') FROM public.clock_events ce
            WHERE ce.staff_id = s.id AND ce.event_type = 'break_end' AND ce.created_at::date = d.day_date
            ORDER BY ce.created_at DESC LIMIT 1
          ),
          'notes', (
            SELECT string_agg(ce.notes, ' | ') FROM public.clock_events ce
            WHERE ce.staff_id = s.id AND ce.created_at::date = d.day_date AND ce.notes <> ''
          ),
          'is_currently_in', (
            SELECT EXISTS (
              SELECT 1 FROM public.clock_events latest
              WHERE latest.staff_id = s.id AND latest.created_at::date = d.day_date
                AND latest.event_type IN ('clock_in','break_end')
                AND latest.created_at = (SELECT MAX(ce3.created_at) FROM public.clock_events ce3 WHERE ce3.staff_id = s.id AND ce3.created_at::date = d.day_date)
            )
          ),
          'current_status', (
            SELECT ce.event_type FROM public.clock_events ce
            WHERE ce.staff_id = s.id AND ce.created_at::date = d.day_date ORDER BY ce.created_at DESC LIMIT 1
          )
        ) ORDER BY d.day_date
      ) FROM generate_series(p_week_start, v_week_end, '1 day'::interval) AS d(day_date)
    ), '[]'::jsonb)
  ) ORDER BY s.display_name
), '[]'::jsonb)
FROM public.staff_members s WHERE s.is_active = true
INTO v_grid;

RETURN v_grid;
END;
$function$;

-- Grant execute on new functions
GRANT EXECUTE ON FUNCTION public.owner_delete_staff_member TO authenticated;
GRANT EXECUTE ON FUNCTION public.owner_save_schedule TO authenticated;
GRANT EXECUTE ON FUNCTION public.owner_update_schedule TO authenticated;
