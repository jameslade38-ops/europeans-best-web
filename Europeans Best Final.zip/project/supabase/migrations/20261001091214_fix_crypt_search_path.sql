/*
# Fix crypt function search_path for staff login

1. Root cause
- The `crypt()` and `gen_salt()` functions from pgcrypto are installed in the `extensions` schema.
- All SECURITY DEFINER staff functions had `search_path=public`, which excludes `extensions`.
- This caused "function crypt(text, text) does not exist" errors when staff tried to sign in.

2. Fix
- Update search_path to `public, extensions` on all SECURITY DEFINER functions that use crypt/gen_salt.
- Also updates functions that call other functions using crypt (staff_dashboard, staff_clock_action, etc).
*/

ALTER FUNCTION public.staff_sign_in(text, text) SET search_path = public, extensions;
ALTER FUNCTION public.staff_dashboard(text) SET search_path = public, extensions;
ALTER FUNCTION public.staff_clock_action(text, text, text) SET search_path = public, extensions;
ALTER FUNCTION public.create_staff_member(text, text, text) SET search_path = public, extensions;
ALTER FUNCTION public.staff_manager_dashboard(text) SET search_path = public, extensions;
ALTER FUNCTION public.staff_manager_update_clock_event(text, uuid, text, timestamptz, text) SET search_path = public, extensions;
ALTER FUNCTION public.auto_clock_out_staff() SET search_path = public, extensions;
ALTER FUNCTION public.owner_auto_clock_out_staff() SET search_path = public, extensions;
ALTER FUNCTION public.owner_update_clock_event(uuid, text, timestamptz, text) SET search_path = public, extensions;