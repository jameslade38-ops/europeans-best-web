/*
# Separate temporary staff preview names

1. Temporary accounts
- Keeps `Temporary` with code `2468` as regular staff.
- Renames the manager preview account to `Manager` with code `1357` so first-name-only login cannot select the wrong account.
*/

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM public.staff_members WHERE lower(display_name) = 'temporary manager') THEN
    UPDATE public.staff_members SET display_name = 'Manager Preview', role = 'manager', is_active = true, pin_hash = crypt('1357', gen_salt('bf')) WHERE lower(display_name) = 'temporary manager';
  ELSIF NOT EXISTS (SELECT 1 FROM public.staff_members WHERE lower(display_name) = 'manager preview') THEN
    INSERT INTO public.staff_members (display_name, role, pin_hash, is_active, can_view_calendar) VALUES ('Manager Preview', 'manager', crypt('1357', gen_salt('bf')), true, true);
  END IF;
END $$;